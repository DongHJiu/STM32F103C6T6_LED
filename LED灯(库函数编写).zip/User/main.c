#include "stm32f10x.h"                  // Device header
#include "LED.h"
#include "Delay.h"

int main(){
	LED_Init();
	while(1){		
		LED_Data(0);
		Delay_ms(1000);
		LED_Data(1);
		Delay_ms(1000);
	}
	
}
